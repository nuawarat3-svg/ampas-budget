// AMPAS — ฐานข้อมูลกลาง ฟอร์มตั้ง Budget 2027 (ข้อ 8) บน Netlify Blobs
// GET  /api/bf?mode=blank&since=<ms>   → {ok, now, depts:{dc:{by,at,p}}} เฉพาะแผนกที่เปลี่ยนหลัง since
// POST /api/bf  body {mode, dc, by, p} → บันทึก 1 แผนก
import { getStore } from "@netlify/blobs";

const json = (o, status = 200) => new Response(JSON.stringify(o), {
  status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
const okMode = m => /^(blank|actual)$/.test(m);

export default async (req) => {
  const store = getStore({ name: "bf2027", consistency: "strong" });
  try {
    if (req.method === "GET") {
      const u = new URL(req.url);
      const mode = u.searchParams.get("mode") || "blank";
      const since = Number(u.searchParams.get("since") || 0);
      if (!okMode(mode)) return json({ ok: false, error: "bad request" }, 400);
      const { blobs } = await store.list({ prefix: mode + "/" });
      const metas = await Promise.all(blobs.map(b => store.getMetadata(b.key).then(m => ({ key: b.key, m: m && m.metadata }))));
      const want = metas.filter(x => x.m && Number(x.m.at) > since);
      const depts = {};
      await Promise.all(want.map(async x => {
        const d = await store.get(x.key, { type: "json" });
        if (d && typeof d.p === "string") depts[x.key.split("/")[1]] = { by: d.by || "", at: Number(d.at), p: d.p };
      }));
      return json({ ok: true, now: Date.now(), depts });
    }
    if (req.method === "POST") {
      let b; try { b = JSON.parse(await req.text()); } catch (e) { return json({ ok: false, error: "bad request" }, 400); }
      const mode = String(b.mode || "blank"), dc = String(b.dc || "");
      if (!okMode(mode) || !/^\d{2,4}$/.test(dc) || typeof b.p !== "string" || b.p.length > 4_000_000) return json({ ok: false, error: "bad request" }, 400);
      try { JSON.parse(b.p); } catch (e) { return json({ ok: false, error: "bad request" }, 400); }
      const at = Date.now(), by = String(b.by || "").slice(0, 80);
      await store.setJSON(mode + "/" + dc, { by, at, p: b.p }, { metadata: { at, by } });
      return json({ ok: true, at });
    }
    return json({ ok: false, error: "method not allowed" }, 405);
  } catch (e) {
    return json({ ok: false, error: String(e && e.message || e) }, 500);
  }
};

export const config = { path: "/api/bf" };
