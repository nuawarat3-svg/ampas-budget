AMPAS Budget 2027 — ติดตั้งฐานข้อมูลกลางบน Netlify (ไม่ใช้ Google)
=====================================================================

ในโฟลเดอร์นี้มี
  index.html                  หน้าเว็บ (ตั้งค่าให้ใช้ฐานข้อมูลกลาง /api/bf แล้ว)
  netlify/functions/bf.mjs    ฐานข้อมูลกลาง (Netlify Function + Netlify Blobs)
  netlify.toml, package.json  ไฟล์ตั้งค่าของ Netlify

สำคัญ: การลากไฟล์ (Drag & Drop) ไม่ติดตั้ง Function ให้ ต้อง deploy ด้วย Netlify CLI ตามขั้นตอนนี้ (ทำครั้งเดียว)

1) ติดตั้ง Node.js (เวอร์ชัน LTS) จาก https://nodejs.org แล้วรีสตาร์ตเครื่อง/เปิด Command Prompt ใหม่
2) แตกไฟล์ zip นี้ไว้ในโฟลเดอร์ เช่น  C:\ampas-budget
3) เปิด Command Prompt แล้วพิมพ์ทีละบรรทัด

     cd C:\ampas-budget
     npm install
     npm install -g netlify-cli
     netlify login
         (เบราว์เซอร์จะเปิดหน้า Netlify ให้กด Authorize)
     netlify link
         (เลือก "Search by full or partial project name" แล้วพิมพ์  deft-llama  เลือกเว็บเดิม)
     netlify deploy --prod

4) ตรวจสอบ: เปิด  https://deft-llama-cddcc9.netlify.app/api/bf?mode=blank
   ต้องขึ้น  {"ok":true,"now":...,"depts":{...}}
5) เปิดหน้าเว็บ ป้ายมุมล่างซ้ายต้องเป็น 🟢 "ข้อมูลกลาง · ทุกคนเห็นตรงกัน"

ครั้งต่อไปที่แก้ index.html ให้รันแค่  netlify deploy --prod  ในโฟลเดอร์เดิม
(ข้อมูลที่แผนกคีย์เก็บใน Netlify Blobs ไม่หายเมื่อ deploy ใหม่)
